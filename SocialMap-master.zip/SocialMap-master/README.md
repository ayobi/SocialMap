# SocialMap
Web application

Version 0.1

http://socialmap.netai.net/

The intention of this web application is to allow users the ability to upload pictures and access pictures from their social media accounts. We then use those pictures to make a collage in the form of map markers indicating where the picture was taken. 
